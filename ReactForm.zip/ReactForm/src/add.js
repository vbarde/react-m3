import React, { Component } from 'react';
class Addproduct extends Component {
    constructor() {
        super();
        this.state = {
            data: {}
        }
    }
    getAllProduct() {
        this.setState({
            data:
            {
                custUName: this.refs.custUName.value,
                custEmail: this.refs.custEmail.value,
                custMobile: this.refs.custMobile.value,
                addr: this.refs.addr.value,
                purpose: this.refs.purpose.value,
                date: this.refs.date.value
            }
        }, function () {
            this.props.getData(this.state.data);
        }
        )
        this.refs.custUName.value = "";
        this.refs.custEmail.value = "";
        this.refs.custMobile.value = "";
        this.refs.addr.value = "";
        this.refs.purpose.value = "";
        this.refs.date.value = "";
    }
    render() {
        return (
            <div>
                <div>
                    <table >
                        <h2>Customer Registration Form</h2>
                        <div class="container-fluid">
                            <tbody><tr >
                                <td><input type="text" placeholder="Username" ref="custUName" /></td></tr>
                                <tr><td><input type="text" ref="custEmail" placeholder="Email id" /></td></tr>
                                <tr><td><input type="text" ref="custMobile" placeholder="Mobile Number" /></td></tr>
                                <tr><td><input type="text" ref="addr" placeholder="Address" /></td></tr>
                                <tr><td><input type="text" ref="purpose" placeholder="Purpose Of Visit" /></td></tr>
                                <tr><td><input type="text" ref="date" placeholder="Date Of Visit" /></td></tr>
                                <tr><td align="left" class="btn btn-info btn-lg"><button onClick={this.getAllProduct.bind(this)} id="sub">Log In</button></td>
                                </tr>
                            </tbody>

                        </div>
                    </table>
                </div>
            </div>
        );
    }
}
export default Addproduct;