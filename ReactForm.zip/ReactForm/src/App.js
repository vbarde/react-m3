import React, { Component } from 'react';
import './App.css';
import Addproduct from './add';
import ShowProduct from './show';
class App extends Component {
  constructor() {
    super();
    this.state = {
      custData: []
    }
  }
  addProduct(data) {
    let olddata = this.state.custData
    olddata.push(data)
    this.setState({
      custData: olddata
    })
  }
  replaceProduct(data, id) {
    let olddata = this.state.custData
    olddata.splice(id, 1, data)
    this.setState({
      custData: olddata
    })
  }
  render() {
    return (
      <div className="App">
        <Addproduct getData={this.addProduct.bind(this)} />
        <ShowProduct pobject={this.state.custData} pobject1={this.replaceProduct.bind(this)} />
      </div>
    );
  }
}
export default App;
